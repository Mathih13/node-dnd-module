module.exports = require('./dist/DNDModule');
